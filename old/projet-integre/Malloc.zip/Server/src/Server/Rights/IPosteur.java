package Server.Rights;

public interface IPosteur
{
    String getID();
}
